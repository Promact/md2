import {componentSanityCheck} from "../../platform/testing/util";

export function main() {
  componentSanityCheck('Divider', 'md-divider', `<md-divider></md-divider>`);
}

