/// <reference path="../../typings/index.d.ts" />

declare var module: { id: string };
