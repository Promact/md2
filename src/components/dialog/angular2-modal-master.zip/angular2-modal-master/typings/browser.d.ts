/// <reference path="browser/ambient/es6-shim/index.d.ts" />
/// <reference path="browser/ambient/node/index.d.ts" />
/// <reference path="browser/ambient/webpack/index.d.ts" />
/// <reference path="browser/definitions/es6-promise/index.d.ts" />
/// <reference path="browser/definitions/zone.js/index.d.ts" />
