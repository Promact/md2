export {IndexComponent} from './index.component';
