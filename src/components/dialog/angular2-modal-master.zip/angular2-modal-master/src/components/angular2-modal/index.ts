// WEBPACK development runtime helper.
export * from './angular2-modal';
