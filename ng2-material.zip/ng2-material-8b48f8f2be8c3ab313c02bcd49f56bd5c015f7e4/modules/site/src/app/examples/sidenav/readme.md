# [<md-sidenav>](https://material.angular.io)

The official `@angular2-material/sidenav` components must be installed for these examples:

View the official documentation: [@angular2-material/sidenav](https://github.com/angular/material2/tree/master/src/components/sidenav)
 
```
npm install --save @angular2-material/sidenav
```
