# [<md-progress-bar>](https://material.angular.io)

The official `@angular2-material/progress-bar` components must be installed for these examples:

View the official documentation: [@angular2-material/progress-bar](https://github.com/angular/material2/tree/master/src/components/progress-bar)
 
```
npm install --save @angular2-material/progress-bar
```
