# [<md-toolbar>](https://material.angular.io)

The official `@angular2-material/toolbar` components must be installed for these examples:

View the official documentation: [@angular2-material/toolbar](https://github.com/angular/material2/tree/master/src/components/toolbar)
 
```
npm install --save @angular2-material/toolbar
```
