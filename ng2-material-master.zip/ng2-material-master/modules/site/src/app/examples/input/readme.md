# [<md-input>](https://material.angular.io)

The official `@angular2-material/input` components must be installed for these examples:

View the official documentation: [@angular2-material/input](https://github.com/angular/material2/tree/master/src/components/input)
 
```
npm install --save @angular2-material/input
```
