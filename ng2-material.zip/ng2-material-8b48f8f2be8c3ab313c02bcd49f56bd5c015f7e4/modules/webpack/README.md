# ng2-material webpack

Ultra-minimal webpack project with ng2-material and material2.

## Getting Started

> npm install
> npm start


## Credits

Webpack example based on https://github.com/preboot/angular2-webpack



