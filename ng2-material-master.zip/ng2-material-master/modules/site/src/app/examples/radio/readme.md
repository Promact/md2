# [<md-radio-button>](https://material.angular.io)

The official `@angular2-material/input` components must be installed for these examples:

View the official documentation: [@angular2-material/radio](https://github.com/angular/material2/tree/master/src/components/radio)
 
```
npm install --save @angular2-material/radio
```
