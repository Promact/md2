# [<md-tab-group>](https://material.angular.io)

The official `@angular2-material/tabs` components must be installed for these examples:

View the official documentation: [@angular2-material/tabs](https://github.com/angular/material2/tree/master/src/components/tabs)
 
```
npm install --save @angular2-material/tabs
```
