# [<md-progress-circle>](https://material.angular.io)

The official `@angular2-material/progress-circle` components must be installed for these examples:

View the official documentation: [@angular2-material/progress-circle](https://github.com/angular/material2/tree/master/src/components/progress-circle)
 
```
npm install --save @angular2-material/progress-circle
```
