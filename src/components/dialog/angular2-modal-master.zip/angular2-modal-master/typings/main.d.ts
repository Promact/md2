/// <reference path="main/ambient/es6-shim/index.d.ts" />
/// <reference path="main/ambient/node/index.d.ts" />
/// <reference path="main/ambient/webpack/index.d.ts" />
/// <reference path="main/definitions/es6-promise/index.d.ts" />
/// <reference path="main/definitions/zone.js/index.d.ts" />
