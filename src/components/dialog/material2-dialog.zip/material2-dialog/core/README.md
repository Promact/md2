Core library code for other `@angular2-material` components.
This should be added as a dependency for any project using the components.
