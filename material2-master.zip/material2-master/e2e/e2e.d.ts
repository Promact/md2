/// <reference path="typings/es6-shim/es6-shim.d.ts" />
/// <reference path="typings/jasmine/jasmine.d.ts" />
/// <reference path="typings/selenium-webdriver/index.d.ts" />
/// <reference path="typings/angular-protractor/index.d.ts" />
