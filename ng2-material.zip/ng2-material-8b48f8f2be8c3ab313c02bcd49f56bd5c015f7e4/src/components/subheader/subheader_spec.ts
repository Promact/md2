import {componentSanityCheck} from "../../platform/testing/util";

export function main() {
  componentSanityCheck('Subheader', 'md-subheader', '<md-subheader></md-subheader>');
}

