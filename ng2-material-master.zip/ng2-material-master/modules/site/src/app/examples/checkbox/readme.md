# [<md-checkbox>](https://material.angular.io)

The official `@angular2-material/checkbox` components must be installed for these examples:

View the official documentation: [@angular2-material/checkbox](https://github.com/angular/material2/tree/master/src/components/checkbox)
 
```
npm install --save @angular2-material/checkbox
```
