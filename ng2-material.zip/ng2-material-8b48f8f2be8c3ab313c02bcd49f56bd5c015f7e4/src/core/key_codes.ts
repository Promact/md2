export enum KeyCodes {
  ESCAPE = 27,
  SPACE  = 32,
  UP     = 38,
  DOWN   = 40,
}
