/// <reference path="es6-promise/es6-promise.d.ts" />
/// <reference path="fs-extra/fs-extra.d.ts" />
/// <reference path="jasmine/jasmine.d.ts" />
/// <reference path="node/node.d.ts" />
